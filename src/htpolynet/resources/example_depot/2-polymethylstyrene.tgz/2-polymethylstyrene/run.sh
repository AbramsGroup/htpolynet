#!/bin/bash -l
# A simple driver to demonstrate usage of HTPolyNet
#
# Cameron F. Abrams cfa22@drexel.edu


sysname="pMSTY"
mollib='./lib/molecules'

# clean out any existing project directories and the library
rm -rf proj-* *log ${mollib}/parameterized/*

# Generate a 2d picture and a 3d mol2 file for methylstyrene's activated
# form, ethylmethylbenzene (EMB) and rename reactive atoms
echo "C1=CC(C)=CC=C1CC" | obabel -ismi --gen2d -opng -O ${mollib}/inputs/EMB.png
echo "C1=CC(C)=CC=C1CC" | obabel -ismi --gen3d -h -omol2 --title "EMB" | \
      sed s/" 8 C "/" 8 C1"/ | \
      sed s/" 9 C "/" 9 C2"/ | \
      sed s/"UNL1"/"EMB "/ > ${mollib}/inputs/EMB.mol2

# launch the build
htpolynet run -diag diagnostics.log ${sysname}.yaml &> console.log
