#!/bin/bash -l
# A simple driver to demonstrate usage of HTPolyNet
#
# Cameron F. Abrams cfa22@drexel.edu


sysname="STY"
mollib='./lib/molecules'

# clean out any existing project directories and the library
rm -rf proj-* *log ${mollib}/parameterized/*

# Generate a 2d picture and a 3d mol2 file for styrene (active/hydrogenated form);
# rename reactive atoms in styrene
STYRENE_ACTIVE_SMILES="C1=CC=CC=C1CC"
obabel -:"$STYRENE_ACTIVE_SMILES" -ismi --gen2d -opng -O ${mollib}/inputs/STY.png
obabel -:"$STYRENE_ACTIVE_SMILES" -ismi -omol2 -h --gen3d --title styrene-active | \
     sed s/" 7 C "/" 7 C1"/ | \
     sed s/" 8 C "/" 8 C2"/ | \
     sed s/"UNL1"/"STY "/ > ${mollib}/inputs/STY.mol2

htpolynet run -diag diagnostics.log ${sysname}.yaml &> console.log
