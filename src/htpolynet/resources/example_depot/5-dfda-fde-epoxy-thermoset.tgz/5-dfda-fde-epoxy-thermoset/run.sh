#!/bin/bash -l
# A simple driver to demonstrate usage of HTPolyNet
#
# Cameron F. Abrams cfa22@drexel.edu


sysname="FDEDFA"
mollib='./lib/molecules'

# clean out any existing project directories and the library
rm -rf proj-* *log ${mollib}/parameterized/*

# Monomer structures:
# Fragments:
FOURAMINOFURANYL="C1OC(CN)=CC=1"
FURANYL=c1occc1
DFDA_SMILES="C(${FOURAMINOFURANYL})${FOURAMINOFURANYL}"
FDE_SMILES="N((C${FURANYL})CC(O)C)CC(O)C"

# DFDA
obabel -:"$DFDA_SMILES" -ismi --gen2d -opng -O ${mollib}/inputs/DFA.png
obabel -:"$DFDA_SMILES" -ismi -h --gen3d --title DFA -opdb \
    | sed s/"UNL "/"DFA "/ \
    | sed s/"HETATM    6  N "/"HETATM    6  N1"/ \
    | sed s/"HETATM   13  N "/"HETATM   13  N2"/ \
    > ${mollib}/inputs/DFA.pdb

# FDE
obabel -:"$FDE_SMILES" -ismi --gen2d -opng -O ${mollib}/inputs/FDE.png
obabel -:"$FDE_SMILES" -ismi -h --gen3d --title FDE -opdb \
    | sed s/"UNL "/"FDE "/ \
    | sed s/"HETATM   11  C "/"HETATM   11  C1/" \
    | sed s/"HETATM   15  C "/"HETATM   15  C2/" \
    | sed s/"HETATM    9  C "/"HETATM    9  C3/" \
    | sed s/"HETATM   13  C "/"HETATM   13  C4/" \
    > ${mollib}/inputs/FDE.pdb

# launch the build
htpolynet run -diag diagnostics.log ${sysname}.yaml &> console.log
