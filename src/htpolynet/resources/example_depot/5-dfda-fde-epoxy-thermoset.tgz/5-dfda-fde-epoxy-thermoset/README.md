# HTPolyNet Example: FDE/DFDA Thermoset

> v1.0.8

## Included in this directory:

- Empty library: `lib/molecules/parameterized/` and `lib/molecules/inputs/`
- Input configuration file: `FDEDFA.yaml`
- Sample bash script `run.sh` that generates input monomer structures and launches `htpolynet run`
- This `README.md`

## Description

This sample `HTPolyNet` run generates a FDE/DFDA thermoset system.  Unlike other runs, this one demonstrates the user of PDB-format input structures instead of mol2-format.

## Instructions

Invoking the bash script will generate the input monomer structure file and then launch `htpolynet run`

> $ ./run.sh

Results will appear in `proj-0`.

## Notes

The bash script as provided here assumes you (1) use conda to manage Python, (2) have a conda environment `mol-env` that is configured to run `htpolynet`, and (3) have access to `obabel`.

If you have configured Python so that it can run `htpolynet` in the base environment or completely outside of conda, you can comment out the line that reads `conda activate mol-env`, or if you have called your custom environment something other than `mol-env`, you of course should edit this line accordingly.

If you do not have OpenBabel installed, then you will need to generate the styrene monomer structure file `STY.mol2` some other way.  For example, you can use ChemSketch or Avogadro to draw the molecule and then export it in `mol2` format.

## Questions?

Feel free to email me at cfa22@drexel.edu
