#!/bin/bash -l
# A simple driver to demonstrate usage of HTPolyNet
#
# Cameron F. Abrams cfa22@drexel.edu


sysname="GMASTY"
mollib='./lib/molecules'

# clean out any existing project directories and the library
rm -rf proj-* *log ${mollib}/parameterized/*

# Generation of input monomer structures
# Styrene, active form
STYRENE="C1=CC=CC=C1CC"
obabel -:"$STYRENE" -ismi --gen2d -opng -O ${mollib}/inputs/STY.png
obabel -:"$STYRENE" -ismi -omol2 -h --gen3d --title "Styrene-active" | \
     sed s/" 7 C "/" 7 C1"/ | \
     sed s/" 8 C "/" 8 C2"/ | \
     sed s/"UNL1"/"STY "/ > ${mollib}/inputs/STY.mol2

# Bisphenol-A
PHENOL="C1=CC=C(O)C=C1"
BPA="CC($PHENOL)($PHENOL)C"
obabel -:"$BPA" -ismi --gen2d -opng -O ${mollib}/inputs/BPA.png -xp 600
obabel -:"$BPA" -ismi --gen3d -h -omol2 --title "Bisphenol A" \
          | sed s/"UNL1"/"BPA "/ \
          | sed s/" 7 O "/" 7 O1"/ \
          | sed s/"14 O "/"14 O2"/ \
          > ${mollib}/inputs/BPA.mol2

# 1-hydroxyethyl methacrylate
HIE="CC(C(=O)OCC(O)C)C"
obabel -:"$HIE" -ismi --gen2d -opng -O ${mollib}/inputs/HIE.png -xp 600
obabel -:"$HIE" -ismi --gen3d -h -omol2 --title "1-hydroxyethyl methacrylate" \
          | sed s/"UNL1"/"HIE "/ \
          | sed s/"10 C "/"10 C2"/ \
          | sed s/" 2 C "/" 2 C1"/ \
          | sed s/" 7 C "/" 7 C3"/ \
          | sed s/" 9 C "/" 9 C4"/ \
          > ${mollib}/inputs/HIE.mol2

# launch the build
htpolynet run -diag diagnostics.log ${sysname}.yaml &> console.log
